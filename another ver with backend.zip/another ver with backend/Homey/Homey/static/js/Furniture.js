function swalfun()
{
    swal(" Thank you for choosing our company.", " ", "success" ,);
}